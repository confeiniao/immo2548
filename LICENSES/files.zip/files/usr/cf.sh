#!/bin/ash

attempt=0
while [ $attempt -lt 20 ]; do
    current_ipv6=$(ip -6 addr show dev pppoe-wan | { while read -r line; do case "$line" in *scope\ global*) set -- $line; echo "${2%/*}"; break;; esac; done; })
    if [ -n "$current_ipv6" ]; then
        break
    fi
    attempt=$((attempt + 1))
    sleep 5
done

if [ -z "$current_ipv6" ]; then
    exit 1
fi

saved_ipv6=""
[ -f "/usr/v6.txt" ] && saved_ipv6=$(cat /usr/v6.txt)

if [ "$current_ipv6" != "$saved_ipv6" ]; then
    webhook_url="https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=8628d3f0-0f08-4074-a4d1-fdd0f2c47b4c"
    headers="Content-Type: application/json"
    neirong="[Home](http://[$current_ipv6]:188)\n\n\n[$current_ipv6]"
    data="{\"msgtype\": \"markdown\", \"markdown\": {\"content\": \"$neirong\"}}"
    wget -q --header="$headers" --post-data="$data" "$webhook_url"
    response=$(wget -qO- "https://z58vv.pages.dev/v-6=$current_ipv6")
        

    if [ "$response" = "v-6 saved successfully." ]; then
        echo "$current_ipv6" > /usr/v6.txt
    fi
fi