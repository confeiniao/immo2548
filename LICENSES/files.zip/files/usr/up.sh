#!/bin/ash

SAVE_PATH=$(ls -t /usr/bin/AdGuardHome/data/filters/*.txt | head -n1) || exit 1
URLS="https://z58x.pages.dev/https://raw.githubusercontent.com/confeiniao/25egeeg/main/st/ad.txt https://raw.githubusercontent.com/confeiniao/25egeeg/main/st/ad.txt"

for URL in $URLS; do
    CONTENT=$(wget -qT 120 -O - "$URL" 2>/dev/null)
    LINE_COUNT=$(echo "$CONTENT" | wc -l)
    if [ "$LINE_COUNT" -gt 20000 ]; then
        echo "$CONTENT" > "$SAVE_PATH"
        echo "规则更新成功！行数: $LINE_COUNT"
        exit 0
    fi
done