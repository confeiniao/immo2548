#!/bin/ash

SAVE_PATH=$(ls -t /usr/bin/AdGuardHome/data/filters/*.txt | head -n1) || exit 1
URLS="https://z58x.pages.dev/https://raw.githubusercontent.com/privacy-protection-tools/anti-AD/master/anti-ad-easylist.txt https://gh-proxy.com/https://raw.githubusercontent.com/privacy-protection-tools/anti-AD/master/anti-ad-easylist.txt https://raw.githubusercontent.com/privacy-protection-tools/anti-AD/master/anti-ad-easylist.txt"

for URL in $URLS; do
    CONTENT=$(wget -qT 120 -O - "$URL" 2>/dev/null)
    LINE_COUNT=$(echo "$CONTENT" | wc -l)
    if [ "$LINE_COUNT" -gt 50000 ]; then
        exit 0
    fi
done