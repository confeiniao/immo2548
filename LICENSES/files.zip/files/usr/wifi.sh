#!/bin/ash

rm -f /usr/wifi.sh
mv -f /usr/wifi2.sh /usr/wifi.sh

uci del firewall.cfg02dc81.network
uci add_list firewall.cfg02dc81.network='lan'
uci del firewall.cfg03dc81.network
uci add_list firewall.cfg03dc81.network='wan'
uci add_list firewall.cfg03dc81.network='wan6'
uci add_list firewall.cfg03dc81.network='wwan'

uci set network.wwan=interface
uci set network.wwan.proto='dhcp'

uci set wireless.wifinet2=wifi-iface
uci set wireless.wifinet2.device='MT7981_1_2'
uci set wireless.wifinet2.mode='sta'
uci set wireless.wifinet2.network='wwan'
uci set wireless.wifinet2.ssid='7092-5G'
uci set wireless.wifinet2.encryption='psk2'
uci set wireless.wifinet2.key='12345678'

uci commit firewall
uci commit network
uci commit wireless
reboot