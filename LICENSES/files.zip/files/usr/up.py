# -*- coding: utf-8 -*-
import os
import urllib.request

urls = [
    "https://z58x.pages.dev/https://raw.githubusercontent.com/privacy-protection-tools/anti-AD/master/anti-ad-easylist.txt",
    "https://raw.githubusercontent.com/privacy-protection-tools/anti-AD/master/anti-ad-easylist.txt"
]

def download_file(url):
    try:
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36 Edg/132.0.0.0"}
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req) as response:
            return response.read().decode('utf-8')
    except Exception as e:
        print(f"下载失败: {url}, 错误: {e}")
        return None

def get_max_filename(directory):
    files = [f for f in os.listdir(directory) if f.endswith('.txt') and f[:-4].isdigit()]
    return os.path.join(directory, max(files, key=lambda x: int(x[:-4]))) if files else None

def main():
    filters_dir = "/usr/bin/AdGuardHome/data/filters"
    
    for url in urls:
        if content := download_file(url):
            print(f"下载成功: {url}")
            if len(content.splitlines()) > 20000:
                if max_file := get_max_filename(filters_dir):
                    with open(max_file, 'w', encoding='utf-8') as f:
                        f.write(content)
                    print(f"内容已写入: {max_file}")
                    break
                print("未找到有效的TXT文件")
            print("内容行数不足2万,尝试下一链接")
        print("下载失败,尝试下一链接")
    else:
        print("所有链接均失败")

if __name__ == "__main__":
    main()