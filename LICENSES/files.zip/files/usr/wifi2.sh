#!/bin/ash

lost=$(ping -c4 -W2 223.5.5.5 2>/dev/null | awk -F'[ ,]+' '/transmitted/ {print $1-$4}')
[ "$lost" -le 1 ] && exit 0

wifi_list="
7092-5G|12345678
CU_E3t4_5G|12345678
ChinaNet-ATC2VL|12345678
888-5G|88888888
"

for entry in $wifi_list; do
    ssid=$(echo "$entry" | cut -d'|' -f1)
    key=$(echo "$entry" | cut -d'|' -f2)

    [ -z "$ssid" ] && continue

    uci set wireless.wifinet2.ssid="$ssid"
    uci set wireless.wifinet2.key="$key"
    uci commit wireless
    wifi reload
    sleep 20

    lost=$(ping -c4 -W2 223.5.5.5 2>/dev/null | awk -F'[ ,]+' '/transmitted/ {print $1-$4}')
    [ "$lost" -le 1 ] && { logger -t 桥接 "✅ 切换成功: $ssid"; exit 0; }
done

logger -t 桥接 "❌ 全部 WiFi 切换失败"
exit 1