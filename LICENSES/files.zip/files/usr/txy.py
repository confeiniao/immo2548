# -*- coding: utf-8 -*-
import zipfile, base64, shutil, hashlib, hmac, json, sys, os, time, urllib.request
from datetime import datetime

def sign(key, msg):
    return hmac.new(key, msg.encode("utf-8"), hashlib.sha256).digest()

def make_request(action, payload="{}", region=""):
    secret_id = "AKIDMiy41oQp7RZUBi4DBwTntnV2MTDm9JF1"
    secret_key = "g9QWQAgz62ly1sWwBE7mEbpsjP6dQ0dU"
    token = ""
    service = "ssl"
    host = "ssl.tencentcloudapi.com"
    version = "2019-12-05"
    algorithm = "TC3-HMAC-SHA256"
    timestamp = int(time.time())
    date = datetime.utcfromtimestamp(timestamp).strftime("%Y-%m-%d")

    http_request_method = "POST"
    canonical_uri = "/"
    canonical_querystring = ""
    ct = "application/json; charset=utf-8"
    canonical_headers = "content-type:%s\nhost:%s\nx-tc-action:%s\n" % (ct, host, action.lower())
    signed_headers = "content-type;host;x-tc-action"
    hashed_request_payload = hashlib.sha256(payload.encode("utf-8")).hexdigest()
    canonical_request = (http_request_method + "\n" +
                        canonical_uri + "\n" +
                        canonical_querystring + "\n" +
                        canonical_headers + "\n" +
                        signed_headers + "\n" +
                        hashed_request_payload)

    credential_scope = date + "/" + service + "/" + "tc3_request"
    hashed_canonical_request = hashlib.sha256(canonical_request.encode("utf-8")).hexdigest()
    string_to_sign = (algorithm + "\n" +
                     str(timestamp) + "\n" +
                     credential_scope + "\n" +
                     hashed_canonical_request)

    secret_date = sign(("TC3" + secret_key).encode("utf-8"), date)
    secret_service = sign(secret_date, service)
    secret_signing = sign(secret_service, "tc3_request")
    signature = hmac.new(secret_signing, string_to_sign.encode("utf-8"), hashlib.sha256).hexdigest()

    authorization = (algorithm + " " +
                    "Credential=" + secret_id + "/" + credential_scope + ", " +
                    "SignedHeaders=" + signed_headers + ", " +
                    "Signature=" + signature)

    headers = {
        "Authorization": authorization,
        "Content-Type": "application/json; charset=utf-8",
        "Host": host,
        "X-TC-Action": action,
        "X-TC-Timestamp": str(timestamp),
        "X-TC-Version": version
    }
    if region:
        headers["X-TC-Region"] = region
    if token:
        headers["X-TC-Token"] = token

    try:
        request = urllib.request.Request(
            url=f"https://{host}",
            data=payload.encode("utf-8"),
            headers=headers,
            method="POST"
        )
        with urllib.request.urlopen(request) as response:
            return response.read().decode("utf-8")
    except Exception as err:
        print(f"请求出错: {err}")
        return None

def get_certificates():
    return make_request("DescribeCertificates")

def download_certificate(certificate_id):
    payload = json.dumps({"CertificateId": certificate_id})
    return make_request("DownloadCertificate", payload)

if __name__ == "__main__":
    try:
        resp_json = json.loads(get_certificates())
        d_certs = sorted([cert for cert in resp_json['Response']['Certificates'] 
                         if cert['Domain'] == 'd.acyun.us.kg'],
                        key=lambda x: x['CertEndTime'], reverse=True)

        if not d_certs[0]['CertificateId']:
            print("未找到d.acyun.us.kg的证书")
            sys.exit(1)

        cert_id = ""
        if os.path.exists("/etc/zs/cert_id.txt"):
            with open("/etc/zs/cert_id.txt") as f:
                cert_id = f.read()
        if d_certs[0]['CertificateId'] in cert_id:
            print("证书ID未变更,无需更新")
            sys.exit(1)

        cert_content = json.loads(download_certificate(d_certs[0]['CertificateId']))
        if not cert_content['Response']['Content']:
            print("下载证书失败，退出")
            sys.exit(1)

        os.makedirs('/etc/zs', exist_ok=True)
        with open('/etc/zs/cert.zip', 'wb') as f:
            f.write(base64.b64decode(cert_content['Response']['Content']))

        with zipfile.ZipFile('/etc/zs/cert.zip') as zip_ref:
            zip_ref.extractall('/etc/zs', members=[f for f in zip_ref.namelist() if f.startswith('Nginx/')])

        for f in os.listdir('/etc/zs/Nginx'):
            if f.endswith(('.crt','.key')):
                shutil.move(os.path.join('/etc/zs/Nginx', f), 
                          os.path.join('/etc/zs', f'uhttpd.{f[-3:]}'))

        shutil.rmtree('/etc/zs/Nginx')
        os.remove('/etc/zs/cert.zip')

        with open('/etc/zs/cert_id.txt', 'w') as f:
            f.write(d_certs[0]['CertificateId'])
        print("Nginx证书更新成功")

    except Exception as err:
        print(f"更新证书失败: {err}")