#!/bin/ash

/bin/sh /usr/share/AdGuardHome/update_core.sh